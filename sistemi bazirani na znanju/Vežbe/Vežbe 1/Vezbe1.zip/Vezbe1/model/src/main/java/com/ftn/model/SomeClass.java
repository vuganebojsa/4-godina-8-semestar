package com.ftn.model;
import org.kie.api.definition.type.PropertyReactive;

@PropertyReactive
public class SomeClass {
    
}
