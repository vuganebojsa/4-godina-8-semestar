package com.ftn.model;

public enum OrderState {
    PENDING, PENDING_URGENT, SHIPPED, COMPLETED, FAILED; 
}
