package rs.ac.uns.ftn.sbz.jena.rdf;

import java.util.stream.IntStream;

import org.apache.log4j.Logger;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.vocabulary.VCARD;

public class Primer3 {

	final static Logger logger = Logger.getLogger(Primer3.class);

	public static void main(String[] args) {
		// some definitions
		String personURI = "http://somewhere/JohnSmith";
		String givenName = "John";
		String familyName = "Smith";
		String fullName = givenName + " " + familyName;
		// create an empty model
		Model model = ModelFactory.createDefaultModel();

		// create the resource
		// and add the properties cascading style
		@SuppressWarnings("unused")
		Resource johnSmith = model.createResource(personURI).addProperty(VCARD.FN, fullName).addProperty(VCARD.N,
				model.createResource().addProperty(VCARD.Given, givenName).addProperty(VCARD.Family, familyName));

		StringBuilder sbStatement = new StringBuilder();
		
		// list the statements in the graph
		StmtIterator iter = model.listStatements();
		printStatements(sbStatement, iter);
		// list the properties of the Resource
//		printResourceAndProperties(sbStatement, johnSmith, 0);
		logger.info(sbStatement.toString());
		
		System.out.println("\n");
		// write it to standard out
        model.write(System.out); 
	
	}

	public static void printStatements(StringBuilder sbStatement, StmtIterator iter) {

		// print out the predicate, subject and object of each statement
		while (iter.hasNext()) {
			Statement stmt = iter.nextStatement(); // get next statement
			Resource subject = stmt.getSubject(); // get the subject
			Property predicate = stmt.getPredicate(); // get the predicate
			RDFNode object = stmt.getObject(); // get the object

			sbStatement.append("STATEMENT:" + subject + " " + predicate + " ");
			if (object instanceof Resource) {
				sbStatement.append(object.toString());
			} else {
				// object is a literal
				sbStatement.append(" \"" + object.toString() + "\"");
			}
			sbStatement.append("\n");
		}

	}

	public static void printResourceAndProperties(StringBuilder sbStatement, Resource obj, int level) {
		IntStream.range(0, level).forEach(i -> sbStatement.append("\t"));
		sbStatement.append(obj.toString()+"\n");
		StmtIterator iter = obj.listProperties();
		level++;
		while (iter.hasNext()) {
			Statement stmt = iter.nextStatement(); // get next statement
			Resource subject = stmt.getSubject(); // get the subject
			Property predicate = stmt.getPredicate(); // get the predicate
			RDFNode object = stmt.getObject(); // get the object
			
			IntStream.range(0, level).forEach(i -> sbStatement.append("\t"));
			
			sbStatement.append("STATEMENT:" + subject + " " + predicate + " ");
			if (object instanceof Resource) {
				sbStatement.append(object.toString()+"\n");
				printResourceAndProperties(sbStatement, (Resource)object, level);
			} else {
				// object is a literal
				sbStatement.append(" \"" + object.toString() + "\"\n");
			}
		}

	}
}
